// Store the name, school, grade, section, rollno and the marks scored by the student in 3 subjects
// Print the report card of the student (You can make it look nice by using some keyboard symbols )
// Explore ASCII ART (https://en.wikipedia.org/wiki/ASCII_art (Links to an external site.)) or Text Art (https://fsymbols.com/text-art/ (Links to an external site.)) for some inspiration
let name="Harshit"
let school="T.H.S.ARA"
let section="C"
let grade="B"
let roll=09
let math=55
let eng=65
let hin=70
console.log("**********************"+"\n"+name+"|"+school+"|  "+grade+"| "+"| "+section+"| "+roll+"| "+"\n"+"***********************")