let r_p=4000;
let d_p=3999;
if( r_p>=d_p){
  console.log("Got discount")
}else{
  console.log("Not eligible")
}