console.log("Masai School"+"\n"+"A Transformation in Education")
