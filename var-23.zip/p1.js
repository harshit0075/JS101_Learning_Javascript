let name="Harshit";
console.log(name);
let father_name="Anup"
console.log(father_name);
let mother_name="Rajani";
console.log(mother_name);