let r_p=4000;
let d_p=3999;
if(r_p>=d_p){
  console.log=(r_p-r_p*0.1)
  
}else{
  console.log("Not eligible")
  
}